<?php exit('Access denied'); __halt_compiler(); ?>
