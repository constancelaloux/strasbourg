<?php

/**
 * This is a placeholder class until we have a TinyMCE editor field.
 *
 * Class SiteOrigin_Widget_Field_Editor
 */
class SiteOrigin_Widget_Field_Editor extends SiteOrigin_Widget_Field_TinyMCE {
	
}