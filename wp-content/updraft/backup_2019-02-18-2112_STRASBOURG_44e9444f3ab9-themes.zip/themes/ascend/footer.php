<?php


			do_action('ascend_after_content'); ?>
			</div><!-- /.wrap -->
			<?php
			do_action('ascend_footer');
			?>
		</div><!--Wrapper-->
		<?php wp_footer(); ?>
	</body>
</html>
