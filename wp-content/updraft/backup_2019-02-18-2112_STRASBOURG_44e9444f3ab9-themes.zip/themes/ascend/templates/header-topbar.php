<div id="topbar" class="topbarclass">
    <div class="container kad-topbar-height topbar-flex">
    	<div class="kt-topbar-left">
	    	<?php 
	        /* 
	        * Hooked ascend_topbar_left 20
	        */
	        do_action('ascend_header_topbar_left');
	        ?>
	    </div>
	    <div class="kt-topbar-right">
		    <?php 
	        /* 
	        * Hooked ascend_topbar_right 20
	        */
	        do_action('ascend_header_topbar_right'); 

	        ?>
	    </div>
    </div> <!-- Close Container -->
</div>