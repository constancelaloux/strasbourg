td, th {
text-align: left;
}

a, a:active, a:visited {
text-decoration: <?php echo ( ( 'underline' === $this->options['underline'] ) ? 'underline' : 'none' ); ?>;
}